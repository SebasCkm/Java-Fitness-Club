/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package fitnessclub_system_java;
import javax.swing.table.DefaultTableModel;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

;

/**
 *
 * @author sebas
 */
public class StaffHomePage extends javax.swing.JFrame {
    private DefaultTableModel studentTableModel;
    private DefaultTableModel trainerTableModel;
    /**
     * Creates new form StaffHomePage
     */
    
    
    public StaffHomePage() {
        initComponents();
        
        
        studentTableModel = new DefaultTableModel(new String[]{"Username", "Password", "Payment"}, 0); // Table model  - Array of Collumn names + 0 = no more collunms
        trainerTableModel = new DefaultTableModel(new String[]{"Username", "Password"}, 0); //Same as above
        
        StudentInfoTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
        @Override
        public void valueChanged(ListSelectionEvent event) {
            if (!event.getValueIsAdjusting()) {
                int selectedRow = StudentInfoTable.getSelectedRow();
                if (selectedRow >= 0) {
                    String StudentUsername = studentTableModel.getValueAt(selectedRow, 0).toString();
                    String StudentPassword = studentTableModel.getValueAt(selectedRow, 1).toString();
                    InputUsernameTF.setText(StudentUsername);
                    InputPasswordTF.setText(StudentPassword);
                }
            }
        }
    });
            
        TrainerInfoTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
        @Override
        public void valueChanged(ListSelectionEvent event) {
            // Check if the row selection is not adjusting (to avoid multiple events)
            if (!event.getValueIsAdjusting()) {
                int selectedRow = TrainerInfoTable.getSelectedRow();
                if (selectedRow >= 0) {
                    String TrianerUsername = trainerTableModel.getValueAt(selectedRow, 0).toString();
                    String TrainerPassword = trainerTableModel.getValueAt(selectedRow, 1).toString();
                    InputUsernameTF.setText(TrianerUsername);
                    InputPasswordTF.setText(TrainerPassword);
                }
            }
        }
    });
        

        
        StudentInfoTable.setModel(studentTableModel); // To connect the table models made above to the coressponding table
        TrainerInfoTable.setModel(trainerTableModel);
        
        loadStudentDataFromTXT(); //Function to load student data from txt file        
        loadTrainerDataFromTXT(); // Function to load Trainer data from txt file
    }
    
        private void loadStudentDataFromTXT() {
    try {
        BufferedReader br = new BufferedReader(new FileReader("StudentInfo.txt"));
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(" ");
            if (parts.length >= 2) { // At least 2 parts are expected (username and password)
                String username = parts[0];
                String password = parts[1];
                String payment = (parts.length > 2) ? parts[2] : ""; // Handle optional payment if present

                studentTableModel.addRow(new Object[]{username, password, payment});
            }
        }
        br.close();
    } catch (IOException e) {
//         used to check if data file can be connected to
//        JOptionPane.showMessageDialog(this, "Error loading Trainer data from file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    }
        
        private void loadTrainerDataFromTXT() {
    try {
        BufferedReader br = new BufferedReader(new FileReader("TrainerInfo.txt"));
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(" ");
            if (parts.length == 2) { // Expecting exactly 2 parts (username and password)
                String username = parts[0];
                String password = parts[1];

                trainerTableModel.addRow(new Object[]{username, password});
            }
        }
        br.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
}
        
        private void updateStudentDataInTXT(int row, String newUsername, String newPassword) {
    try {
        // Read all the lines from the TXT before update
        BufferedReader br = new BufferedReader(new FileReader("StudentInfo.txt"));
        String[] lines = br.lines().toArray(String[]::new);
        br.close();

        // Check if the selected data exists
        if (row >= 0 && row < lines.length) {
            // Seperate the Username and Password 
            String[] parts = lines[row].split(" ");
            
            if (parts.length >= 2) { // Check if there are at least 2 columns (username password)
                parts[0] = newUsername;
                parts[1] = newPassword;

                // If there is a third column (payment), keep it
                if (parts.length >= 3) {
                    parts[2] = studentTableModel.getValueAt(row, 2).toString();
                }

                // Write the updated data back to TXT
                lines[row] = String.join(" ", parts);
                
                BufferedWriter bw = new BufferedWriter(new FileWriter("StudentInfo.txt"));
                for (int i = 0; i < lines.length; i++) {
                    bw.write(lines[i]);
                    if (i < lines.length - 1) {
                        bw.newLine(); // Add newline only if it's not the last line
                    }
                }
                bw.close();
                
                // Clear the TFs
                InputUsernameTF.setText("");
                InputPasswordTF.setText("");

                // Update the Trainer table model
                studentTableModel.setValueAt(newUsername, row, 0);
                studentTableModel.setValueAt(newPassword, row, 1);

                JOptionPane.showMessageDialog(this, "Student updated successfully!", "Update Student", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Error when Writing to Text File.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Error when Writing to Text File.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error when Writing to Text File" , "Error", JOptionPane.ERROR_MESSAGE);
    }
}
        
        
        private void updateTrainerDataInTXT(int row, String newUsername, String newPassword) {
    try {
        // Read all the lines from the TXT before update
        BufferedReader br = new BufferedReader(new FileReader("TrainerInfo.txt"));
        String[] lines = br.lines().toArray(String[]::new);
        br.close();

        // Check if the selected data exists
        if (row >= 0 && row < lines.length) {
            // Seperate the Username and Password 
            String[] parts = lines[row].split(" ");
            
            //Check ot see of there is Username and Password
            if (parts.length == 2) {
                parts[0] = newUsername;
                parts[1] = newPassword;

                // Write the updated data back to TXT
                lines[row] = String.join(" ", parts);
                
                BufferedWriter bw = new BufferedWriter(new FileWriter("TrainerInfo.txt"));
                for (int i = 0; i < lines.length; i++) {
                    bw.write(lines[i]);
                    if (i < lines.length - 1) {
                        bw.newLine(); // Add newline only if it's not the last line
                    }
                }
                bw.close();
                
                // Clear the TFs
                InputUsernameTF.setText("");
                InputPasswordTF.setText("");

                // Update the Trainer table model
                trainerTableModel.setValueAt(newUsername, row, 0);
                trainerTableModel.setValueAt(newPassword, row, 1);

                JOptionPane.showMessageDialog(this, "Trainer updated successfully!", "Update Trainer", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Error when Writing to Text File.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Error when Writing to Text File.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error when Writing to Text File" , "Error", JOptionPane.ERROR_MESSAGE);
    }
}
        
        private void updateStudentPaymentInTXT(int row, String newPayment) {
    try {
        //Open TXT to READ
        File file = new File("StudentInfo.txt");
        BufferedReader br = new BufferedReader(new FileReader(file));

        // Read all lines and store as list
        List<String> lines = new ArrayList<>();
        String line;
        while ((line = br.readLine()) != null) {
            lines.add(line);
        }
        br.close();

        // Check if exists
        if (row >= 0 && row < lines.size()) {
            // Split the line into parts
            String[] parts = lines.get(row).split(" ");

            // Update the payment part of the line
            if (parts.length >= 3) {
                parts[2] = newPayment; // Update the payment 
            } else {
                // If payment empty, adddd
                lines.set(row, lines.get(row) + " " + newPayment);
            }

            // Write file with updated list
            BufferedWriter bw = new BufferedWriter(new FileWriter(file));
            for (String updatedLine : lines) {
                bw.write(updatedLine);
                bw.newLine();
            }
            bw.close();


        } else {
            JOptionPane.showMessageDialog(this, "Invalid row selected.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error when Writing to Text File", "Error", JOptionPane.ERROR_MESSAGE);
    }
}







        

        
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        StaffHomePageEXITbtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        StudentInfoTable = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        TrainerInfoTable = new javax.swing.JTable();
        InputUsernameTF = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        InputPasswordTF = new javax.swing.JPasswordField();
        jLabel5 = new javax.swing.JLabel();
        AddStudentbtn = new javax.swing.JButton();
        UpdateStudentbtn = new javax.swing.JButton();
        DeleteStudentbtn = new javax.swing.JButton();
        ChargeStudentbtn = new javax.swing.JButton();
        StudentPaymentbtn = new javax.swing.JButton();
        SearchStudentbtn = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        AddTrainerbtn = new javax.swing.JButton();
        UpdateTrainerbtn = new javax.swing.JButton();
        DeleteTrainerbtn = new javax.swing.JButton();
        SearchTrainerbtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 204, 153));

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Welcome To APU Fitness Club");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Staff Home Page");

        StaffHomePageEXITbtn.setBackground(new java.awt.Color(204, 204, 204));
        StaffHomePageEXITbtn.setText("Log Out");
        StaffHomePageEXITbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StaffHomePageEXITbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 578, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(StaffHomePageEXITbtn)
                .addGap(18, 18, 18))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(StaffHomePageEXITbtn))
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        StudentInfoTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        StudentInfoTable.setColumnSelectionAllowed(true);
        StudentInfoTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(StudentInfoTable);
        StudentInfoTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        TrainerInfoTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        TrainerInfoTable.setColumnSelectionAllowed(true);
        TrainerInfoTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(TrainerInfoTable);
        TrainerInfoTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Username: ");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("Password: ");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Student Actions: ");

        AddStudentbtn.setText("Add Student");
        AddStudentbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddStudentbtnActionPerformed(evt);
            }
        });

        UpdateStudentbtn.setText("Update Student");
        UpdateStudentbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateStudentbtnActionPerformed(evt);
            }
        });

        DeleteStudentbtn.setText("Delete Student");
        DeleteStudentbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteStudentbtnActionPerformed(evt);
            }
        });

        ChargeStudentbtn.setText("Charge Student");
        ChargeStudentbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChargeStudentbtnActionPerformed(evt);
            }
        });

        StudentPaymentbtn.setText("Payment");
        StudentPaymentbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StudentPaymentbtnActionPerformed(evt);
            }
        });

        SearchStudentbtn.setText("Search Student");
        SearchStudentbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchStudentbtnActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Trainer Actions");

        AddTrainerbtn.setText("Add Trainer");
        AddTrainerbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddTrainerbtnActionPerformed(evt);
            }
        });

        UpdateTrainerbtn.setText("Update Trainer");
        UpdateTrainerbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateTrainerbtnActionPerformed(evt);
            }
        });

        DeleteTrainerbtn.setText("Delete Trainer");
        DeleteTrainerbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteTrainerbtnActionPerformed(evt);
            }
        });

        SearchTrainerbtn.setText("Search Trainer");
        SearchTrainerbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchTrainerbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(InputUsernameTF, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(InputPasswordTF, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addGap(1, 1, 1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(126, 126, 126)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(AddStudentbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(18, 18, 18)
                                        .addComponent(UpdateStudentbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(ChargeStudentbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(18, 18, 18)
                                        .addComponent(StudentPaymentbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(5, 5, 5)))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(SearchStudentbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(DeleteStudentbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(2, 2, 2))
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(AddTrainerbtn)
                                .addGap(26, 26, 26)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(SearchTrainerbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(UpdateTrainerbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(DeleteTrainerbtn)))
                        .addGap(111, 111, 111)))
                .addGap(20, 20, 20))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddStudentbtn)
                    .addComponent(UpdateStudentbtn)
                    .addComponent(DeleteStudentbtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ChargeStudentbtn)
                    .addComponent(StudentPaymentbtn)
                    .addComponent(SearchStudentbtn))
                .addGap(24, 24, 24)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddTrainerbtn)
                    .addComponent(UpdateTrainerbtn)
                    .addComponent(DeleteTrainerbtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SearchTrainerbtn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(InputUsernameTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(InputPasswordTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void UpdateStudentbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateStudentbtnActionPerformed
    // get the input from the TFs
    String newUsername = InputUsernameTF.getText();
    String newPassword = new String(InputPasswordTF.getPassword());

    int selectedRow = StudentInfoTable.getSelectedRow();

    if (selectedRow >= 0) {
        // Update data in tqable
        studentTableModel.setValueAt(newUsername, selectedRow, 0);
        studentTableModel.setValueAt(newPassword, selectedRow, 1);

        // Update data in TXT
        updateStudentDataInTXT(selectedRow, newUsername, newPassword);

        // Clear the TFs
        InputUsernameTF.setText("");
        InputPasswordTF.setText("");

//        JOptionPane.showMessageDialog(this, "Student updated successfully!", "Update Student", JOptionPane.INFORMATION_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(this, "Please select a student from the table.", "Update Student", JOptionPane.ERROR_MESSAGE);
}
    }//GEN-LAST:event_UpdateStudentbtnActionPerformed

    private void ChargeStudentbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChargeStudentbtnActionPerformed
    int selectedRow = StudentInfoTable.getSelectedRow();
    if (selectedRow >= 0) {
        String newPayment = "200";
        updateStudentPaymentInTXT(selectedRow, newPayment);
        //Refresh table to show updated data
        studentTableModel.setRowCount(0);
        loadStudentDataFromTXT();
        
        JOptionPane.showMessageDialog(this, "Payment updated successfully!", "Update Payment", JOptionPane.INFORMATION_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(this, "Please select a student to charge.", "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_ChargeStudentbtnActionPerformed

    private void AddStudentbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddStudentbtnActionPerformed
           // Retrieve the input from the TFs
    String UsernameTF = InputUsernameTF.getText();
    String PasswordTF = new String(InputPasswordTF.getPassword());

    
    if (!UsernameTF.isEmpty() && !PasswordTF.isEmpty()) { // Only will excetue when InputTF not empty
        try {
            // Call FileWriter and BufferedWriter
            FileWriter fileWriter = new FileWriter("StudentInfo.txt", true); 
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            // Write the username and password in file .... Divided by space " "
            bufferedWriter.write(UsernameTF + " " + PasswordTF);
            bufferedWriter.newLine(); // Next line for next row
            bufferedWriter.close();

            // Clear TFs
            InputUsernameTF.setText("");
            InputPasswordTF.setText("");

            // Update Student Info Table after successful 
            studentTableModel.addRow(new String[]{UsernameTF, PasswordTF});

            JOptionPane.showMessageDialog(this, "Student added successfully!!!", "Add Student", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error adding Student to file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        // Show an error message if fields are empty
        JOptionPane.showMessageDialog(this, "Please ensure that both Username and Password Fields are filled!!!", "Add Student", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_AddStudentbtnActionPerformed

    private void AddTrainerbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddTrainerbtnActionPerformed
           // Retrieve the input from the TFs
    String UsernameTF = InputUsernameTF.getText();
    String PasswordTF = new String(InputPasswordTF.getPassword());

    
    if (!UsernameTF.isEmpty() && !PasswordTF.isEmpty()) { // Only will excetue when InputTF not empty
        try {
            // Call FileWriter and BufferedWriter
            FileWriter fileWriter = new FileWriter("TrainerInfo.txt", true); 
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            // Write the username and password in file .... Divided by space " "
            bufferedWriter.write(UsernameTF + " " + PasswordTF);
            bufferedWriter.newLine(); // Next line for next row
            bufferedWriter.close();

            // Clear TFs
            InputUsernameTF.setText("");
            InputPasswordTF.setText("");

            // Update Student Info Table after successful 
            trainerTableModel.addRow(new String[]{UsernameTF, PasswordTF});

            JOptionPane.showMessageDialog(this, "Trainer added successfully!!!", "Add Trainer", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error adding Trainer to file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        // Show an error message if fields are empty
        JOptionPane.showMessageDialog(this, "Please ensure that both Username and Password Fields are filled!!!", "Add Trainer", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_AddTrainerbtnActionPerformed

    private void UpdateTrainerbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateTrainerbtnActionPerformed
    // get the input from the TFs
    String newUsername = InputUsernameTF.getText();
    String newPassword = new String(InputPasswordTF.getPassword());

    int selectedRow = TrainerInfoTable.getSelectedRow();

    if (selectedRow >= 0) {
        // Update data in tqable
        trainerTableModel.setValueAt(newUsername, selectedRow, 0);
        trainerTableModel.setValueAt(newPassword, selectedRow, 1);

        // Update data in TXT
        updateTrainerDataInTXT(selectedRow, newUsername, newPassword);

        // Clear the TFs
        InputUsernameTF.setText("");
        InputPasswordTF.setText("");

//        JOptionPane.showMessageDialog(this, "Trainer updated successfully!", "Update Trainer", JOptionPane.INFORMATION_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(this, "Please select a Trainer from the table.", "Update Trainer", JOptionPane.ERROR_MESSAGE);
}
    }//GEN-LAST:event_UpdateTrainerbtnActionPerformed

    private void DeleteStudentbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteStudentbtnActionPerformed
    int selectedRow = StudentInfoTable.getSelectedRow();

    if (selectedRow >= 0) {
        try {
            //This method uses two files one input (ORI) and one Output (TEMP)
            // Open the input(ORI)
            File inputFile = new File("StudentInfo.txt");
            BufferedReader br = new BufferedReader(new FileReader(inputFile));
            String line;
            
            // Create a Output(TEMP) file to write updated data
            File tempFile = new File("StudentInfo_temp.txt");
            BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile));
            
            while ((line = br.readLine()) != null) {
                // Split the line into parts
                String[] parts = line.split(" ");

                // Confirm line to be deleted (based on the selected row)
                if (parts.length >= 2 && studentTableModel.getValueAt(selectedRow, 0).equals(parts[0]) &&
                    studentTableModel.getValueAt(selectedRow, 1).equals(parts[1])) {
                    // If not then skip
                    continue;
                }

                // Write the line to the temporary file
                bw.write(line);
                bw.newLine();
            }

            // Close both the input(ORI) and output(TEMP) files
            br.close();
            bw.close();

            // Delete the input(ORI) file and rename the output(TEMP) file
            inputFile.delete();
            tempFile.renameTo(inputFile);

            // Remove the row from the table model
            studentTableModel.removeRow(selectedRow);

            JOptionPane.showMessageDialog(this, "Student deleted successfully!!!!", "Delete Student", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error deleting Student from file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please select a Student from the table.", "Delete Student", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_DeleteStudentbtnActionPerformed

    private void DeleteTrainerbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteTrainerbtnActionPerformed
    int selectedRow = TrainerInfoTable.getSelectedRow();

    if (selectedRow >= 0) {
        try {
            //This method uses two files one input (ORI) and one Output (TEMP)
            // Open the input(ORI)
            File inputFile = new File("TrainerInfo.txt");
            BufferedReader br = new BufferedReader(new FileReader(inputFile));
            String line;
            
            // Create a Output(TEMP) file to write updated data
            File tempFile = new File("TrainerInfo_temp.txt");
            BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile));
            
            while ((line = br.readLine()) != null) {
                // Split the line into parts
                String[] parts = line.split(" ");

                // Confirm line to be deleted (based on the selected row)
                if (parts.length >= 2 && trainerTableModel.getValueAt(selectedRow, 0).equals(parts[0]) &&
                    trainerTableModel.getValueAt(selectedRow, 1).equals(parts[1])) {
                    // If not then skip
                    continue;
                }

                // Write the line to the temporary file
                bw.write(line);
                bw.newLine();
            }

            // Close both the input(ORI) and output(TEMP) files
            br.close();
            bw.close();

            // Delete the input(ORI) file and rename the output(TEMP) file
            inputFile.delete();
            tempFile.renameTo(inputFile);

            // Remove the row from the table model
            trainerTableModel.removeRow(selectedRow);

            JOptionPane.showMessageDialog(this, "Trainer deleted successfully!!!!", "Delete Trainer", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error deleting Trainer from file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please select a Trainer from the table.", "Delete Trainer", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_DeleteTrainerbtnActionPerformed

    private void SearchStudentbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchStudentbtnActionPerformed
    // Get query from UsernameTF
    String searchQuery = InputUsernameTF.getText().trim().toLowerCase(); // Convert to lowercase for case-insensitive search

    // Clear selected row
    StudentInfoTable.clearSelection();

    // Loop studentTableModel to find matches
    for (int i = 0; i < studentTableModel.getRowCount(); i++) {
        String username = studentTableModel.getValueAt(i, 0).toString().toLowerCase(); // Convert to lowercase for case-insensitive comparison

        // Check if the query input is related to any in data
        if (username.contains(searchQuery)) {
            // If got a match, select the row
            StudentInfoTable.addRowSelectionInterval(i, i);
        }
    }
    }//GEN-LAST:event_SearchStudentbtnActionPerformed

    private void SearchTrainerbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchTrainerbtnActionPerformed
    // Get query from UsernameTF
    String searchQuery = InputUsernameTF.getText().trim().toLowerCase(); // Convert to lowercase for case-insensitive search

    // Clear selected row
    TrainerInfoTable.clearSelection();

    // Loop studentTableModel to find matches
    for (int i = 0; i < trainerTableModel.getRowCount(); i++) {
        String username = trainerTableModel.getValueAt(i, 0).toString().toLowerCase(); // Convert to lowercase for case-insensitive comparison

        // Check if the query input is related to any in data
        if (username.contains(searchQuery)) {
            // If got a match, select the row
            TrainerInfoTable.addRowSelectionInterval(i, i);
        }
    }
    }//GEN-LAST:event_SearchTrainerbtnActionPerformed

    private void StaffHomePageEXITbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffHomePageEXITbtnActionPerformed
        LandingPage LandingPageFrame = new LandingPage();
        LandingPageFrame.setVisible(true);
        this.setVisible(false);  
        LandingPageFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_StaffHomePageEXITbtnActionPerformed

    private void StudentPaymentbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StudentPaymentbtnActionPerformed
    int selectedRow = StudentInfoTable.getSelectedRow();//let user select row

    if (selectedRow >= 0) {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to mark this student as 'Paid'?", "Confirm Payment", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            // Update the payment to PAID
            studentTableModel.setValueAt("Paid", selectedRow, 2); // Assuming payment is in the third column (index 2)

            // Update the payment in TXT 
            updateStudentPaymentInTXT(selectedRow, "Paid");

            JOptionPane.showMessageDialog(this, "Payment status updated to 'Paid'!", "Payment Status", JOptionPane.INFORMATION_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please select a student from the table.", "Update Payment Status", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_StudentPaymentbtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StaffHomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StaffHomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StaffHomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StaffHomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StaffHomePage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddStudentbtn;
    private javax.swing.JButton AddTrainerbtn;
    private javax.swing.JButton ChargeStudentbtn;
    private javax.swing.JButton DeleteStudentbtn;
    private javax.swing.JButton DeleteTrainerbtn;
    private javax.swing.JPasswordField InputPasswordTF;
    private javax.swing.JTextField InputUsernameTF;
    private javax.swing.JButton SearchStudentbtn;
    private javax.swing.JButton SearchTrainerbtn;
    private javax.swing.JButton StaffHomePageEXITbtn;
    private javax.swing.JTable StudentInfoTable;
    private javax.swing.JButton StudentPaymentbtn;
    private javax.swing.JTable TrainerInfoTable;
    private javax.swing.JButton UpdateStudentbtn;
    private javax.swing.JButton UpdateTrainerbtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
