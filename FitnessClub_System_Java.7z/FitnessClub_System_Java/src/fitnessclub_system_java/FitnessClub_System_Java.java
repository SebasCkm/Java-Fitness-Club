
package fitnessclub_system_java;


public class FitnessClub_System_Java {

    
    public static void main(String[] args) {


        LandingPage LandingPageFrame = new LandingPage();
        LandingPageFrame.setVisible(true);
        LandingPageFrame.setLocationRelativeTo(null); 
    }
    
}
