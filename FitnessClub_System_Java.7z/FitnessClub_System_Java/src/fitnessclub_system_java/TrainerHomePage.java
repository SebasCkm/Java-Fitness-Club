/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package fitnessclub_system_java;

import javax.swing.table.DefaultTableModel;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.*;
;

/**
 *
 * @author sebas
 */
public class TrainerHomePage extends javax.swing.JFrame {
    
    private DefaultTableModel TrainerScheduleTableModel;
    private DefaultTableModel StudentPaymentTableModel;
    
    /**
     * Creates new form TrainerHomePage
     */
    public TrainerHomePage() {
        initComponents();
        
        TrainerScheduleTableModel = new DefaultTableModel(new String[]{"Trainer Name", "Activity", "Location", "Time", "Date"}, 0);
        StudentPaymentTableModel = new DefaultTableModel(new String[]{"Username", "Payment"}, 0);
        
        TrainerScheduleTable.setModel(TrainerScheduleTableModel);
        StudentPaymentTable.setModel(StudentPaymentTableModel);

        
        // Add a ListSelectionListener to TrainerScheduleTable
        TrainerScheduleTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    // Get the selected row
                    int selectedRow = TrainerScheduleTable.getSelectedRow();

                    // Check if a row is selected
                    if (selectedRow != -1) {
                        // Get data from the selected row and update the text fields
                        String trainerName = TrainerScheduleTableModel.getValueAt(selectedRow, 0).toString();
                        String activity = TrainerScheduleTableModel.getValueAt(selectedRow, 1).toString();
                        String location = TrainerScheduleTableModel.getValueAt(selectedRow, 2).toString();
                        String time = TrainerScheduleTableModel.getValueAt(selectedRow, 3).toString();
                        String date = TrainerScheduleTableModel.getValueAt(selectedRow, 4).toString();


                        TrainerNameInputTF.setText(trainerName);
                        TrainerActivityInputTF.setText(activity);
                        TrainerLocationInputTF.setText(location);
                        TrainerTimerInputTF.setText(time);
                        TrainerDateInputTF.setText(date);
                    }
                }
            }
        });
        
        
        loadStudentDataFromTXT(); // Load data from TXT
        loadScheduleDataFromTXT(); // Load data from TXT
        
    }

    private void loadStudentDataFromTXT() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("StudentInfo.txt"));
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(" ");
                if (parts.length == 3) { // Check if there are at least three parts (columns)
                    String username = parts[0];
                    String payment = parts[2];
                    StudentPaymentTableModel.addRow(new Object[]{username, payment});
                }
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
        private void loadScheduleDataFromTXT() {
        try {
             BufferedReader br = new BufferedReader(new FileReader("TrainerSchedule.txt"));
             String line;
              while ((line = br.readLine()) != null) {
                 String[] parts = line.split(" ");
                   if (parts.length == 5) { // Check if there are exactly four parts (columns)
                      String name = parts[0];
                      String activity = parts[1];
                      String location = parts[2];
                      String time = parts[3];
                      String date = parts[4];
                      
                TrainerScheduleTableModel.addRow(new Object[]{name, activity, location, time, date});
            }
        }
        br.close();
    } catch (IOException e) {
        e.printStackTrace();
    }

    }
        
        private void updateDataInTXTFile() {
    try {
        // Open TXT to write
        FileWriter fw = new FileWriter("TrainerSchedule.txt");
        PrintWriter pw = new PrintWriter(fw);

        // Write data from updated table to TXT
        for (int i = 0; i < TrainerScheduleTableModel.getRowCount(); i++) {
            String trainerName = TrainerScheduleTableModel.getValueAt(i, 0).toString();
            String activity = TrainerScheduleTableModel.getValueAt(i, 1).toString();
            String location = TrainerScheduleTableModel.getValueAt(i, 2).toString();
            String time = TrainerScheduleTableModel.getValueAt(i, 3).toString();
            String date = TrainerScheduleTableModel.getValueAt(i, 4).toString();

            pw.println(trainerName + " " + activity + " " + location + " " + time + " " + date);
        }

        // Close TXT
        pw.close();
        fw.close();
    } catch (IOException e) {
        e.printStackTrace();
        // Handle Error
        JOptionPane.showMessageDialog(this, "An error occurred while updating the file.", "Error Writing", JOptionPane.ERROR_MESSAGE);
    }
}
 
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        TrainerHomePageLogout = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        StudentPaymentTable = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        TrainerScheduleTable = new javax.swing.JTable();
        TrainerNameInputTF = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        TrainerActivityInputTF = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        TrainerLocationInputTF = new javax.swing.JTextField();
        TrainerTimerInputTF = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        GetUsernameInputTF = new javax.swing.JTextField();
        TrainerSearchStudentbtn = new javax.swing.JButton();
        AddSchedule = new javax.swing.JButton();
        DeleteSchedule = new javax.swing.JButton();
        TrainerUpdateSchedulebtn = new javax.swing.JButton();
        TrainerDateInputTF = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 204, 153));

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));

        TrainerHomePageLogout.setBackground(new java.awt.Color(204, 204, 204));
        TrainerHomePageLogout.setText("Logout");
        TrainerHomePageLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TrainerHomePageLogoutActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Welcome To APU Fitness Club");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Trainer Home Page");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(140, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 384, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addComponent(TrainerHomePageLogout)
                .addGap(18, 18, 18))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(TrainerHomePageLogout)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        StudentPaymentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        StudentPaymentTable.setColumnSelectionAllowed(true);
        StudentPaymentTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(StudentPaymentTable);
        StudentPaymentTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        TrainerScheduleTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        TrainerScheduleTable.setColumnSelectionAllowed(true);
        TrainerScheduleTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(TrainerScheduleTable);
        TrainerScheduleTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        TrainerNameInputTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TrainerNameInputTFActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Trainer Name:");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setText("Activity:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("Location: ");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("Time:");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Username:");

        TrainerSearchStudentbtn.setText("Search Student");
        TrainerSearchStudentbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TrainerSearchStudentbtnActionPerformed(evt);
            }
        });

        AddSchedule.setText("Add");
        AddSchedule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddScheduleActionPerformed(evt);
            }
        });

        DeleteSchedule.setText("Delete");
        DeleteSchedule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteScheduleActionPerformed(evt);
            }
        });

        TrainerUpdateSchedulebtn.setText("Update");
        TrainerUpdateSchedulebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TrainerUpdateSchedulebtnActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("Date:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(65, 65, 65)
                                    .addComponent(TrainerSearchStudentbtn)))
                            .addGap(164, 164, 164)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGap(24, 24, 24)))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(TrainerDateInputTF, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(TrainerActivityInputTF)
                                .addComponent(TrainerLocationInputTF)
                                .addComponent(TrainerTimerInputTF)
                                .addComponent(TrainerNameInputTF, javax.swing.GroupLayout.Alignment.TRAILING))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(GetUsernameInputTF, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(20, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(AddSchedule)
                .addGap(18, 18, 18)
                .addComponent(TrainerUpdateSchedulebtn)
                .addGap(19, 19, 19)
                .addComponent(DeleteSchedule)
                .addGap(52, 52, 52))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(TrainerNameInputTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(TrainerActivityInputTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(GetUsernameInputTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(TrainerLocationInputTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TrainerSearchStudentbtn))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(TrainerTimerInputTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TrainerDateInputTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddSchedule)
                    .addComponent(DeleteSchedule)
                    .addComponent(TrainerUpdateSchedulebtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TrainerHomePageLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TrainerHomePageLogoutActionPerformed
        LandingPage LandingPageFrame = new LandingPage();
        LandingPageFrame.setVisible(true);
        this.setVisible(false);  
        LandingPageFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_TrainerHomePageLogoutActionPerformed

    private void TrainerSearchStudentbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TrainerSearchStudentbtnActionPerformed
     // Get query from GetUsernameInputTF
    String searchQuery = GetUsernameInputTF.getText().trim().toLowerCase(); // Convert to lowercase for case-insensitive search

    // Clear selected row
    StudentPaymentTable.clearSelection();

    // Loop studentTableModel to find matches
    for (int i = 0; i < StudentPaymentTableModel.getRowCount(); i++) {
        String username = StudentPaymentTableModel.getValueAt(i, 0).toString().toLowerCase(); // Convert to lowercase for case-insensitive comparison

        // Check if the query input is related to any in data
        if (username.contains(searchQuery)) {
            // If got a match, select the row
            StudentPaymentTable.addRowSelectionInterval(i, i);
            
            // Update GetUsernameInputTF with the matched username
            GetUsernameInputTF.setText(StudentPaymentTableModel.getValueAt(i, 0).toString());
        }
    }
    }//GEN-LAST:event_TrainerSearchStudentbtnActionPerformed

    private void TrainerNameInputTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TrainerNameInputTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TrainerNameInputTFActionPerformed

    private void AddScheduleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddScheduleActionPerformed
    //Get input ffrom TFs
    String trainerName = TrainerNameInputTF.getText().trim();
    String activity = TrainerActivityInputTF.getText().trim();
    String location = TrainerLocationInputTF.getText().trim();
    String timeStr = TrainerTimerInputTF.getText().trim();
    String date = TrainerDateInputTF.getText().trim();

    //Check if TF empty
    if (trainerName.isEmpty() || activity.isEmpty() || location.isEmpty() || timeStr.isEmpty() || date.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Add Schedule Error", JOptionPane.ERROR_MESSAGE);
        return; // Exit if error
    }
    // Change time from string to double and validate input
    double time;
    try {
        time = Double.parseDouble(timeStr);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Please enter a valid time (numeric value).", "Add Schedule Error", JOptionPane.ERROR_MESSAGE);
        return; // Exit if error
    }

    // Add input into file and update table
    TrainerScheduleTableModel.addRow(new Object[]{trainerName, activity, location, time, date});
    updateDataInTXTFile();

    // Clear TFs
    TrainerNameInputTF.setText("");
    TrainerActivityInputTF.setText("");
    TrainerLocationInputTF.setText("");
    TrainerTimerInputTF.setText("");
    TrainerDateInputTF.setText("");

    JOptionPane.showMessageDialog(this, "Schedule added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_AddScheduleActionPerformed

    private void DeleteScheduleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteScheduleActionPerformed
    // Get Selection from table
    int selectedRow = TrainerScheduleTable.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a schedule to delete.", "Error", JOptionPane.ERROR_MESSAGE);
        return; // Exit if error
   
    }

    // Confirm with the user before deleting
    int confirmDelete = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this schedule?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
    
    if (confirmDelete != JOptionPane.YES_OPTION) {
        return; // Exit if error
    }

    // Remove from table
    TrainerScheduleTableModel.removeRow(selectedRow);

    // Update TXT
    updateDataInTXTFile();

    // Clear TFs
    TrainerNameInputTF.setText("");
    TrainerActivityInputTF.setText("");
    TrainerLocationInputTF.setText("");
    TrainerTimerInputTF.setText("");
    TrainerDateInputTF.setText("");

    JOptionPane.showMessageDialog(this, "Schedule deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_DeleteScheduleActionPerformed

    private void TrainerUpdateSchedulebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TrainerUpdateSchedulebtnActionPerformed
    // Get selected row form table
    int selectedRow = TrainerScheduleTable.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a schedule to update.", "Update Schedule Error", JOptionPane.ERROR_MESSAGE);
        return; // Exit if error
    }

    // Get input from TFs
    String trainerName = TrainerNameInputTF.getText().trim();
    String activity = TrainerActivityInputTF.getText().trim();
    String location = TrainerLocationInputTF.getText().trim();
    String timeStr = TrainerTimerInputTF.getText().trim();
    String date = TrainerDateInputTF.getText().trim();

    // Check if TF empty
    if (trainerName.isEmpty() || activity.isEmpty() || location.isEmpty() || timeStr.isEmpty() || date.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Update Schedule Error", JOptionPane.ERROR_MESSAGE);
        return; // Exit if error
    }

    // Change time from string to double and validate input
    double time;
    try {
        time = Double.parseDouble(timeStr);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Please enter a valid time (numeric value).", "Update Schedule Error", JOptionPane.ERROR_MESSAGE);
        return; // Exit if error
    }

    // Update table
    TrainerScheduleTableModel.setValueAt(trainerName, selectedRow, 0);
    TrainerScheduleTableModel.setValueAt(activity, selectedRow, 1);
    TrainerScheduleTableModel.setValueAt(location, selectedRow, 2);
    TrainerScheduleTableModel.setValueAt(time, selectedRow, 3);
    TrainerScheduleTableModel.setValueAt(date, selectedRow, 4);

    // Update TXT
    updateDataInTXTFile();

    // Clear TFs
    TrainerNameInputTF.setText("");
    TrainerActivityInputTF.setText("");
    TrainerLocationInputTF.setText("");
    TrainerTimerInputTF.setText("");
    TrainerDateInputTF.setText("");

    JOptionPane.showMessageDialog(this, "Schedule updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_TrainerUpdateSchedulebtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TrainerHomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TrainerHomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TrainerHomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TrainerHomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TrainerHomePage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddSchedule;
    private javax.swing.JButton DeleteSchedule;
    private javax.swing.JTextField GetUsernameInputTF;
    private javax.swing.JTable StudentPaymentTable;
    private javax.swing.JTextField TrainerActivityInputTF;
    private javax.swing.JTextField TrainerDateInputTF;
    private javax.swing.JButton TrainerHomePageLogout;
    private javax.swing.JTextField TrainerLocationInputTF;
    private javax.swing.JTextField TrainerNameInputTF;
    private javax.swing.JTable TrainerScheduleTable;
    private javax.swing.JButton TrainerSearchStudentbtn;
    private javax.swing.JTextField TrainerTimerInputTF;
    private javax.swing.JButton TrainerUpdateSchedulebtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
