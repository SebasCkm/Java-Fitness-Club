/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package fitnessclub_system_java;
import javax.swing.table.DefaultTableModel;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

;

/**
 *
 * @author sebas
 */
public class StaffHomePage extends javax.swing.JFrame {
    private DefaultTableModel studentTableModel;
    private DefaultTableModel trainerTableModel;
    /**
     * Creates new form StaffHomePage
     */
    
    
    public StaffHomePage() {
        initComponents();
        
        
        studentTableModel = new DefaultTableModel(new String[]{"Username", "Password", "Payment"}, 0); // Table model  - Array of Collumn names + 0 = no more collunms
        trainerTableModel = new DefaultTableModel(new String[]{"Username", "Password"}, 0); //Same as above
        
        StudentInfoTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
        @Override
        public void valueChanged(ListSelectionEvent event) {
            if (!event.getValueIsAdjusting()) {
                int selectedRow = StudentInfoTable.getSelectedRow();
                if (selectedRow >= 0) {
                    String StudentUsername = studentTableModel.getValueAt(selectedRow, 0).toString();
                    String StudentPassword = studentTableModel.getValueAt(selectedRow, 1).toString();
                    
                    
                    InputUsernameTF.setText(StudentUsername);
                    InputPasswordTF.setText(StudentPassword);
                }
            }
        }
    });
            
        TrainerInfoTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
        @Override
        public void valueChanged(ListSelectionEvent event) {
            if (!event.getValueIsAdjusting()) {
                int selectedRow = TrainerInfoTable.getSelectedRow();
                if (selectedRow >= 0) {
                    String TrianerUsername = trainerTableModel.getValueAt(selectedRow, 0).toString();
                    String TrainerPassword = trainerTableModel.getValueAt(selectedRow, 1).toString();
                    
                    
                    InputUsernameTF.setText(TrianerUsername);
                    InputPasswordTF.setText(TrainerPassword);
                }
            }
        }
    });
        

        
        StudentInfoTable.setModel(studentTableModel); // To connect the table models made above to the coressponding table
        TrainerInfoTable.setModel(trainerTableModel);
        
        loadStudentDataFromTXT(); //Function to load student data from txt file        
        loadTrainerDataFromTXT(); // Function to load Trainer data from txt file
    }
    
        private void loadStudentDataFromTXT() {
    try {
        BufferedReader br = new BufferedReader(new FileReader("StudentInfo.txt"));
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(" ");
            if (parts.length >= 2) { // At least 2 parts are expected (username and password)
                String username = parts[0];
                String password = parts[1];
                String payment = (parts.length > 2) ? parts[2] : ""; // Handle optional payment if present

                studentTableModel.addRow(new Object[]{username, password, payment});
            }
        }
        br.close();
    } catch (IOException e) {
//         used to check if data file can be connected to
//        JOptionPane.showMessageDialog(this, "Error loading Trainer data from file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    }
        
        private void loadTrainerDataFromTXT() {
    try {
        BufferedReader br = new BufferedReader(new FileReader("TrainerInfo.txt"));
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(" ");
            if (parts.length == 2) { // Expecting exactly 2 parts (username and password)
                String username = parts[0];
                String password = parts[1];

                trainerTableModel.addRow(new Object[]{username, password});
            }
        }
        br.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
}
        
        private void updateStudentDataInTXTFile(String usernameToDelete) {
    try {
        // Open TXT to write
        FileWriter fw = new FileWriter("StudentInfo.txt");
        PrintWriter pw = new PrintWriter(fw);

        // Write data from updated table to TXT
        for (int i = 0; i < studentTableModel.getRowCount(); i++) {
            String username = studentTableModel.getValueAt(i, 0).toString();
            String password = studentTableModel.getValueAt(i, 1).toString();
            String payment = studentTableModel.getValueAt(i, 2).toString();

            // Skip the line with the username enterd so that when it writes the file again it will skip it and not be included in the updated TXT
            if (!username.equals(usernameToDelete)) {
                pw.println(username + " " + password + " " + payment);
            }
        }

        // Close the TXT
        pw.close();
        fw.close();
    } catch (IOException e) {
        e.printStackTrace();
        // Handle ERROR
        JOptionPane.showMessageDialog(this, "An error occurred while updating the file.", "Error Writhing", JOptionPane.ERROR_MESSAGE);
    }
}
        
        private void updateStudentDataInTXTFile() {
    try {
        // Open TXT to write
        FileWriter fw = new FileWriter("StudentInfo.txt");
        PrintWriter pw = new PrintWriter(fw);

        // Write data from updated table to TXT
        for (int i = 0; i < studentTableModel.getRowCount(); i++) {
            String username = studentTableModel.getValueAt(i, 0).toString();
            String password = studentTableModel.getValueAt(i, 1).toString();
            String payment = studentTableModel.getValueAt(i, 2).toString(); 

            // Write data from updated table to TXT
            pw.println(username + " " + password + " " + payment);
        }

        // Close the file
        pw.close();
        fw.close();
    } catch (IOException e) {
        e.printStackTrace();
        // Handle Error
        JOptionPane.showMessageDialog(this, "An error occurred while updating student data in the file.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}
        
        private void updateTrainerDataInTXTFile() {
    try {
        // Open TXT to write
        FileWriter fw = new FileWriter("TrainerInfo.txt");
        PrintWriter pw = new PrintWriter(fw);

        // Write data from updated table to TXT
        for (int i = 0; i < trainerTableModel.getRowCount(); i++) {
            String username = trainerTableModel.getValueAt(i, 0).toString();
            String password = trainerTableModel.getValueAt(i, 1).toString();
           

            // Write data from updated table to TXT
            pw.println(username + " " + password);
        }

        // Close the file
        pw.close();
        fw.close();
    } catch (IOException e) {
        e.printStackTrace();
        // Handle Error
        JOptionPane.showMessageDialog(this, "An error occurred while updating student data in the file.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}
        

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        StaffHomePageEXITbtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        StudentInfoTable = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        TrainerInfoTable = new javax.swing.JTable();
        InputUsernameTF = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        InputPasswordTF = new javax.swing.JPasswordField();
        jLabel5 = new javax.swing.JLabel();
        AddStudentbtn = new javax.swing.JButton();
        UpdateStudentbtn = new javax.swing.JButton();
        DeleteStudentbtn = new javax.swing.JButton();
        ChargeStudentbtn = new javax.swing.JButton();
        SearchStudentbtn = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        AddTrainerbtn = new javax.swing.JButton();
        UpdateTrainerbtn = new javax.swing.JButton();
        DeleteTrainerbtn = new javax.swing.JButton();
        SearchTrainerbtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 204, 153));

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Welcome To APU Fitness Club");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Staff Home Page");

        StaffHomePageEXITbtn.setBackground(new java.awt.Color(204, 204, 204));
        StaffHomePageEXITbtn.setText("Log Out");
        StaffHomePageEXITbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StaffHomePageEXITbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 578, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(StaffHomePageEXITbtn)
                .addGap(18, 18, 18))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(StaffHomePageEXITbtn))
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        StudentInfoTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        StudentInfoTable.setColumnSelectionAllowed(true);
        StudentInfoTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(StudentInfoTable);
        StudentInfoTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        TrainerInfoTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        TrainerInfoTable.setColumnSelectionAllowed(true);
        TrainerInfoTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(TrainerInfoTable);
        TrainerInfoTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Username: ");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("Password: ");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Student Actions: ");

        AddStudentbtn.setText("Add Student");
        AddStudentbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddStudentbtnActionPerformed(evt);
            }
        });

        UpdateStudentbtn.setText("Update Student");
        UpdateStudentbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateStudentbtnActionPerformed(evt);
            }
        });

        DeleteStudentbtn.setText("Delete Student");
        DeleteStudentbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteStudentbtnActionPerformed(evt);
            }
        });

        ChargeStudentbtn.setText("Charge/Payment");
        ChargeStudentbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChargeStudentbtnActionPerformed(evt);
            }
        });

        SearchStudentbtn.setText("Search Student");
        SearchStudentbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchStudentbtnActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Trainer Actions");

        AddTrainerbtn.setText("Add Trainer");
        AddTrainerbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddTrainerbtnActionPerformed(evt);
            }
        });

        UpdateTrainerbtn.setText("Update Trainer");
        UpdateTrainerbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateTrainerbtnActionPerformed(evt);
            }
        });

        DeleteTrainerbtn.setText("Delete Trainer");
        DeleteTrainerbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteTrainerbtnActionPerformed(evt);
            }
        });

        SearchTrainerbtn.setText("Search Trainer");
        SearchTrainerbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchTrainerbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(InputUsernameTF, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(InputPasswordTF, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addGap(1, 1, 1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(126, 126, 126)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(AddStudentbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(18, 18, 18)
                                .addComponent(UpdateStudentbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(18, 18, 18)
                                .addComponent(DeleteStudentbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(2, 2, 2))
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(AddTrainerbtn)
                                .addGap(26, 26, 26)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(SearchTrainerbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(UpdateTrainerbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(DeleteTrainerbtn))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addComponent(ChargeStudentbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(51, 51, 51)
                                .addComponent(SearchStudentbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(46, 46, 46)))
                        .addGap(111, 111, 111)))
                .addGap(20, 20, 20))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddStudentbtn)
                    .addComponent(UpdateStudentbtn)
                    .addComponent(DeleteStudentbtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ChargeStudentbtn)
                    .addComponent(SearchStudentbtn))
                .addGap(24, 24, 24)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddTrainerbtn)
                    .addComponent(UpdateTrainerbtn)
                    .addComponent(DeleteTrainerbtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SearchTrainerbtn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(InputUsernameTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(InputPasswordTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void UpdateStudentbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateStudentbtnActionPerformed
    //Get selected row form table
    int selectedRow = StudentInfoTable.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a student to update.", "Update Student Error", JOptionPane.ERROR_MESSAGE);
        return; // Exit if error
    }

    // Get input from TFs
    String updatedUsername = InputUsernameTF.getText().trim();
    String updatedPassword = new String(InputPasswordTF.getPassword()).trim(); // Get password as string

    // Check if TF empty
    if (updatedUsername.isEmpty() || updatedPassword.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter both username and password for the update.", "Update Student Error", JOptionPane.ERROR_MESSAGE);
        return; // Exit if error
    }

    // Update table
    studentTableModel.setValueAt(updatedUsername, selectedRow, 0);
    studentTableModel.setValueAt(updatedPassword, selectedRow, 1);

    //  Update TXT
    updateStudentDataInTXTFile();

    // Clear TFs
    InputUsernameTF.setText("");
    InputPasswordTF.setText("");

    JOptionPane.showMessageDialog(this, "Student data updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

    }//GEN-LAST:event_UpdateStudentbtnActionPerformed

    private void ChargeStudentbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChargeStudentbtnActionPerformed
    int selectedRow = StudentInfoTable.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a student to manage payments.", "Payment Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Get selected student username and payment
    String selectedUsername = studentTableModel.getValueAt(selectedRow, 0).toString();
    String selectedPayment = studentTableModel.getValueAt(selectedRow, 2).toString(); 

    // Open the StudentPayment form and pass the selectedUsername and payment
    StudentPayment studentPaymentForm = new StudentPayment(selectedUsername, selectedPayment);
    studentPaymentForm.setVisible(true);
    this.setVisible(false); 
    studentPaymentForm.setLocationRelativeTo(null);
    }//GEN-LAST:event_ChargeStudentbtnActionPerformed

    private void AddStudentbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddStudentbtnActionPerformed
     // Get input  from TFs
    String StudentUsername = InputUsernameTF.getText().trim();
    String password = new String(InputPasswordTF.getPassword());

    // Check TF not empty
    if (StudentUsername.isEmpty() || password.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Username and Password are required.", "Add Student Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Append student into TXT
    try {
        BufferedWriter bw = new BufferedWriter(new FileWriter("StudentInfo.txt", true));

        // Set payment to 0 for new students
        String payment = "0";

        // Write student into TXT
        bw.write(StudentUsername + " " + password + " " + payment);
        bw.newLine();
        bw.close();

        // Add new to table
        studentTableModel.addRow(new Object[]{StudentUsername, password, payment});

        // Clear TFs
        InputUsernameTF.setText("");
        InputPasswordTF.setText("");

        JOptionPane.showMessageDialog(this, "Student added successfully!!!", "Add Student Success", JOptionPane.INFORMATION_MESSAGE);
    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error adding student data to file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_AddStudentbtnActionPerformed

    private void AddTrainerbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddTrainerbtnActionPerformed
             // Get input  from TFs
    String TrainerUsername = InputUsernameTF.getText().trim();
    String TrainerPassword = new String(InputPasswordTF.getPassword());

    // Check TF not empty
    if (TrainerUsername.isEmpty() || TrainerPassword.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Username and Password are required.", "Add Trainer Error", JOptionPane.ERROR_MESSAGE);
        return;
    }    
        
        // Append student into TXT
    try {
        BufferedWriter bw = new BufferedWriter(new FileWriter("TrainerInfo.txt", true));

        // Write student into TXT
        bw.write(TrainerUsername + " " + TrainerPassword);
        bw.newLine();
        bw.close();

        // Add new to table
        trainerTableModel.addRow(new Object[]{TrainerUsername, TrainerPassword});

        // Clear TFs
        InputUsernameTF.setText("");
        InputPasswordTF.setText("");

        JOptionPane.showMessageDialog(this, "Student added successfully!!!", "Add Student Success", JOptionPane.INFORMATION_MESSAGE);
    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error adding student data to file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_AddTrainerbtnActionPerformed

    private void UpdateTrainerbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateTrainerbtnActionPerformed
            //Get selected row form table
    int selectedRow = TrainerInfoTable.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a trainer to update.", "Update Trainer Error", JOptionPane.ERROR_MESSAGE);
        return; // Exit if error
    }

    // Get input from TFs
    String updatedUsername = InputUsernameTF.getText().trim();
    String updatedPassword = new String(InputPasswordTF.getPassword()).trim(); // Get password as string

    // Check if TF empty
    if (updatedUsername.isEmpty() || updatedPassword.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter both username and password for the update.", "Update Trainer Error", JOptionPane.ERROR_MESSAGE);
        return; // Exit if error
    }

    // Update table
    trainerTableModel.setValueAt(updatedUsername, selectedRow, 0);
    trainerTableModel.setValueAt(updatedPassword, selectedRow, 1);

    //  Update TXT
    updateStudentDataInTXTFile();

    // Clear TFs
    InputUsernameTF.setText("");
    InputPasswordTF.setText("");

    JOptionPane.showMessageDialog(this, "Trainer data updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

    }//GEN-LAST:event_UpdateTrainerbtnActionPerformed

    private void DeleteStudentbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteStudentbtnActionPerformed
    // Get selected row index from StudentInfoTable
    int selectedRow = StudentInfoTable.getSelectedRow();

    // Check if a row is selected
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a student to delete.", "Error", JOptionPane.ERROR_MESSAGE);
        return; // Exit if no row is selected
    }

    // Confirm the deletion with a dialog box
    int confirmDelete = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this student?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);

    if (confirmDelete != JOptionPane.YES_OPTION) {
        return; // Exit if the user cancels the deletion
    }

    // Get the username of the selected student
    String usernameToDelete = studentTableModel.getValueAt(selectedRow, 0).toString();

    // Remove the selected row from the studentTableModel
    studentTableModel.removeRow(selectedRow);

    // Update the data in the TXT file (similar to Trainer Schedule update)
    updateStudentDataInTXTFile(usernameToDelete);

    // Clear input fields (if needed)
    InputUsernameTF.setText("");
    InputPasswordTF.setText("");

    JOptionPane.showMessageDialog(this, "Student deleted successfully!", "Delete Student Success", JOptionPane.INFORMATION_MESSAGE);

  
    }//GEN-LAST:event_DeleteStudentbtnActionPerformed

    private void DeleteTrainerbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteTrainerbtnActionPerformed
    // Get selected row index from StudentInfoTable
    int selectedRow = TrainerInfoTable.getSelectedRow();

    // Check if a row is selected
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a Trainer to delete.", "Delete Trainer Error", JOptionPane.ERROR_MESSAGE);
        return; // Exit if no row is selected
    }

    // Confirm the deletion with a dialog box
    int confirmDelete = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this trainer?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);

    if (confirmDelete != JOptionPane.YES_OPTION) {
        return; // Exit if the user cancels the deletion
    }

    // Get the username of the selected student
    String usernameToDelete = trainerTableModel.getValueAt(selectedRow, 0).toString();

    // Remove the selected row from the studentTableModel
    trainerTableModel.removeRow(selectedRow);

    // Update the data in the TXT file (similar to Trainer Schedule update)
    updateStudentDataInTXTFile(usernameToDelete);

    // Clear input fields (if needed)
    InputUsernameTF.setText("");
    InputPasswordTF.setText("");

    JOptionPane.showMessageDialog(this, "Trainer deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

  
    }//GEN-LAST:event_DeleteTrainerbtnActionPerformed

    private void SearchStudentbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchStudentbtnActionPerformed
    // Get query from UsernameTF
    String searchQuery = InputUsernameTF.getText().trim().toLowerCase(); // Convert to lowercase for case-insensitive search

    // Clear selected row
    StudentInfoTable.clearSelection();

    // Loop studentTableModel to find matches
    for (int i = 0; i < studentTableModel.getRowCount(); i++) {
        String username = studentTableModel.getValueAt(i, 0).toString().toLowerCase(); // Convert to lowercase for case-insensitive comparison

        // Check if the query input is related to any in data
        if (username.contains(searchQuery)) {
            // If got a match, select the row
            StudentInfoTable.addRowSelectionInterval(i, i);
        }
    }
    }//GEN-LAST:event_SearchStudentbtnActionPerformed

    private void SearchTrainerbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchTrainerbtnActionPerformed
    // Get query from UsernameTF
    String searchQuery = InputUsernameTF.getText().trim().toLowerCase(); // Convert to lowercase for case-insensitive search

    // Clear selected row
    TrainerInfoTable.clearSelection();

    // Loop studentTableModel to find matches
    for (int i = 0; i < trainerTableModel.getRowCount(); i++) {
        String username = trainerTableModel.getValueAt(i, 0).toString().toLowerCase(); // Convert to lowercase for case-insensitive comparison

        // Check if the query input is related to any in data
        if (username.contains(searchQuery)) {
            // If got a match, select the row
            TrainerInfoTable.addRowSelectionInterval(i, i);
        }
    }
    }//GEN-LAST:event_SearchTrainerbtnActionPerformed

    private void StaffHomePageEXITbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffHomePageEXITbtnActionPerformed
        LandingPage LandingPageFrame = new LandingPage();
        LandingPageFrame.setVisible(true);
        this.setVisible(false);  
        LandingPageFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_StaffHomePageEXITbtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StaffHomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StaffHomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StaffHomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StaffHomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StaffHomePage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddStudentbtn;
    private javax.swing.JButton AddTrainerbtn;
    private javax.swing.JButton ChargeStudentbtn;
    private javax.swing.JButton DeleteStudentbtn;
    private javax.swing.JButton DeleteTrainerbtn;
    private javax.swing.JPasswordField InputPasswordTF;
    private javax.swing.JTextField InputUsernameTF;
    private javax.swing.JButton SearchStudentbtn;
    private javax.swing.JButton SearchTrainerbtn;
    private javax.swing.JButton StaffHomePageEXITbtn;
    private javax.swing.JTable StudentInfoTable;
    private javax.swing.JTable TrainerInfoTable;
    private javax.swing.JButton UpdateStudentbtn;
    private javax.swing.JButton UpdateTrainerbtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
